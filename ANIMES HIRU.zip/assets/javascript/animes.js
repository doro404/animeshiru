import { apitodosanimes } from "./config.js";

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const animeId = urlParams.get('id');
    if (animeId) {
        fetch(`${apitodosanimes}${animeId}`)
            .then(response => response.json())
            .then(data => {

                const alternativeTitles = data.tituloAlternativo ? `, ${data.tituloAlternativo}` : '';
                const pageTitle = `${data.titulo}${alternativeTitles} - Todos Episódios - Animes Online`;
                document.title = pageTitle;

                // Atualiza a descrição da página com base nos dados recebidos
                const pageDescription = `${data.titulo}${alternativeTitles} (${data.anoLancamento}) é um anime ${data.tipoMidia} que você pode assistir online em FHD. Todos os episódios completos estão disponíveis para streaming gratuito. ${data.sinopse} Assista agora e descubra por que ${data.titulo} é tão popular entre os fãs de anime!`;
                
                // Cria o elemento meta description se não existir
                let metaDescription = document.querySelector('meta[name="description"]');
                if (!metaDescription) {
                    metaDescription = document.createElement('meta');
                    metaDescription.name = 'description';
                    document.head.appendChild(metaDescription);
                }
                metaDescription.content = pageDescription;

                const animeTitleText = `${data.titulo}${alternativeTitles} - Todos Episódios - Animes Online`;
                document.getElementById('anime-title').textContent = animeTitleText;
                document.getElementById('anime-title-breadcrumb').textContent = data.titulo;
                document.getElementById('anime-cover').src = data.capa;
                document.getElementById('anime-language').textContent = 'Legendado em Português Brasil';
                document.getElementById('anime-synopsis').innerHTML = `<p>${data.sinopse}</p>`;
                document.getElementById('anime-names').textContent = `${data.titulo}, ${data.tituloAlternativo}`;
                document.getElementById('anime-type').textContent = data.tipoMidia;
                document.getElementById('anime-status').textContent = data.status;
                document.getElementById('anime-language-detail').textContent = 'Legendado em Português Brasil';
    
                document.getElementById('anime-authors').textContent = data.autores ? data.autores.join(', ') : '???';
                document.getElementById('anime-directors').textContent = data.diretor;
                document.getElementById('anime-studio').textContent = data.estudio;
                document.getElementById('anime-release').textContent = data.anoLancamento;
                document.getElementById('anime-views').textContent = data.visualizacoes;
    
                const genresList = document.getElementById('anime-genres');
                const genresDetail = document.getElementById('anime-genres-detail');
                genresList.innerHTML = '';
                genresDetail.innerHTML = '';
    
                data.generos.forEach(genre => {
                    const genreItem = document.createElement('li');
                    genreItem.classList.add('anime-genres__item');
                    genreItem.innerHTML = `<a href="./anime-list" class="anime-genres__link">${genre}</a>`;
                    genresList.appendChild(genreItem);
    
                    const genreLink = document.createElement('a');
                    genreLink.href = "./anime-list";
                    genreLink.classList.add('datasheet__link');
                    genreLink.textContent = genre;
                    genresDetail.appendChild(genreLink);
                });
    
                const episodesContainer = document.getElementById('anime-episodes');
                episodesContainer.innerHTML = '';
                data.episodios.forEach(ep => {
                    const episodeItem = document.createElement('div');
                    episodeItem.classList.add('anime-episodes__item');
                    episodeItem.setAttribute('data-episode-id', ep.numero);
                    episodeItem.innerHTML = `
                        <div class="anime-episodes__thumbnail-box">
                            <img src="${ep.capa_ep}" class="anime-episodes__thumbnail-img">
                        </div>
                        <span class="anime-episodes__division"></span>
                        <div class="anime-episodes__info">
                            <a href="#" class="anime-episodes__title">${ep.nome}</a>
                            <span class="anime-episodes__date">${new Date(data.dataPostagem).toLocaleDateString('pt-BR')}</span>
                        </div>
                    `;
                    episodesContainer.appendChild(episodeItem);
                });
    
                // Add click event listeners to episode items
                document.querySelectorAll('.anime-episodes__item').forEach(item => {
                    item.addEventListener('click', (event) => {
                        event.preventDefault(); // Prevent default link behavior
                        const episodeNumero = item.getAttribute('data-episode-id');
                        if (episodeNumero) {
                            // Construct URL with animeId and episodeNumero
                            window.location.href = `./episode?id=${animeId}&ep=${episodeNumero}`;
                        }
                    });
                });
    
                // Update the section title with the total number of episodes
                const episodesCount = data.episodios.length;
                const sectionTitle = document.querySelector('.section__title');
                sectionTitle.textContent = `Lista de Episodios (${episodesCount})`;

                const optimizedTitle = `Assistir ${data.titulo}${alternativeTitles} Completo em HD Grátis - Todos Episódios Online - Anime Online - animes legendado - animes dublado`;
                const tagsElement = document.querySelector('h2.tags');
                if (tagsElement) {
                    tagsElement.textContent = optimizedTitle;
                }
            
            })
            .catch(error => console.error('Error fetching anime data:', error));
    } else {
        console.error('Anime ID not found in URL');
    }
});
