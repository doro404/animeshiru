import { apianimepagina } from "./config.js";

document.addEventListener('DOMContentLoaded', () => {
    const apianimesPagina = apianimepagina;
    const resultsContainer = document.getElementById('anime-list-resultado');
    const paginationContainer = document.getElementById('pagination-list');
    const letterButtons = document.querySelectorAll('.letters-box__link');

    let letraAtual = '';
    let paginaAtual = 1;
    let totalPages = 1; // Inicializa o total de páginas

    // Função para obter o valor do parâmetro da URL
    function getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    }

    // Função para carregar animes da página específica com o filtro aplicado
    function loadAnimes(pagina = 1, letra = '') {
        const url = `${apianimesPagina}${pagina}`;
        fetch(url)
            .then(response => response.json())
            .then(data => {
                // Filtra animes pela letra se houver uma letra selecionada
                const filteredAnimes = letra ? data.animes.filter(anime => anime.titulo.startsWith(letra)) : data.animes;

                // Limpa resultados anteriores
                resultsContainer.innerHTML = '';

                if (Array.isArray(filteredAnimes) && filteredAnimes.length > 0) {
                    const fragment = document.createDocumentFragment(); // Utiliza DocumentFragment para desempenho

                    filteredAnimes.forEach(anime => {
                        const animeElement = document.createElement('div');
                        animeElement.classList.add('anime-item');
                    
                        const genero = anime.genero ? anime.genero.split(',').map(g => `<span class="anime-item__genre">${g.trim()}</span>`).join('') : '';
                    
                        animeElement.innerHTML = `
                            <div class="anime-item__left">
                                <a href="./single-anime?id=${anime.id}">
                                    <img src="${anime.capa}" alt="${anime.titulo}" class="anime-item__cover">
                                </a>
                            </div>
                            <div class="anime-item__right">
                                <h2 class="anime-item__title"><a href="./single-anime?id=${anime.id}">${anime.titulo}</a></h2>
                                <p class="anime-item__seal">${anime.selo}</p>
                                <div class="anime-item__genres">
                                    ${genero}
                                </div>
                            </div>
                        `;
                    
                        // Adiciona evento de clique ao elemento animeElement
                        animeElement.addEventListener('click', () => {
                            window.location.href = `./single-anime?id=${anime.id}`;
                        });
                    
                        // Impede que o clique nos links internos dispare o evento de clique do elemento pai
                        animeElement.querySelectorAll('a').forEach(link => {
                            link.addEventListener('click', (event) => {
                                event.stopPropagation();
                            });
                        });
                    
                        fragment.appendChild(animeElement);
                    });
                    

                    resultsContainer.appendChild(fragment);
                } else {
                    resultsContainer.innerHTML = '<p>Nenhum resultado encontrado.</p>';
                }

                // Atualiza a paginação com base no total de páginas
                createPagination(totalPages, pagina);
            })
            .catch(error => {
                console.error('Erro ao buscar dados:', error);
            });
    }

    // Função para criar a paginação
    function createPagination(totalPages, paginaAtual) {
        paginationContainer.innerHTML = ''; // Limpa paginação anterior

        const fragment = document.createDocumentFragment(); // Utiliza DocumentFragment para desempenho

        for (let i = 1; i <= totalPages; i++) {
            const pageItem = document.createElement('li');
            pageItem.classList.add('pagination__item');

            if (i === paginaAtual) {
                pageItem.innerHTML = `<span class="pagination__link box--active">${i}</span>`;
            } else {
                pageItem.innerHTML = `<a href="#" class="pagination__link" data-page="${i}">${i}</a>`;
            }

            fragment.appendChild(pageItem);

            // Adiciona o evento de clique após o item ser adicionado ao DOM
            pageItem.addEventListener('click', (e) => {
                e.preventDefault();
                const pagina = parseInt(e.target.getAttribute('data-page'));
                if (pagina !== paginaAtual) { // Evita recarregar a mesma página
                    paginaAtual = pagina;
                    loadAnimes(paginaAtual, letraAtual); // Carrega a nova página com o filtro atual
                    window.history.pushState({}, '', `?pagina=${paginaAtual}&letra=${letraAtual}`); // Atualiza a URL com o novo parâmetro
                }
            });
        }

        paginationContainer.appendChild(fragment);
    }

    // Função para aplicar o filtro de letra
    function applyLetterFilter(letra) {
        letraAtual = letra;
        loadAnimes(paginaAtual, letraAtual); // Carrega a página atual com o filtro aplicado
        window.history.pushState({}, '', `?pagina=${paginaAtual}&letra=${letra}`); // Atualiza a URL com o novo parâmetro
    }

    // Adiciona eventos de clique para os botões de letra
    letterButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const letra = e.target.textContent.trim();
            applyLetterFilter(letra);
        });
    });

    // Obtém o valor da página e letra a partir dos parâmetros da URL ou usa padrões
    paginaAtual = parseInt(getQueryParam('pagina')) || 1;
    letraAtual = getQueryParam('letra') || '';

    // Carrega a página inicial ou a filtrada
    fetch(`${apianimesPagina}1`)
        .then(response => response.json())
        .then(data => {
            totalPages = data.totalPages;
            loadAnimes(paginaAtual, letraAtual);
        })
        .catch(error => {
            console.error('Erro ao buscar dados da primeira página:', error);
        });

    // Adiciona um evento para lidar com a navegação com o histórico
    window.addEventListener('popstate', () => {
        const pagina = parseInt(getQueryParam('pagina')) || 1;
        const letra = getQueryParam('letra') || '';
        paginaAtual = pagina;
        letraAtual = letra;
        loadAnimes(paginaAtual, letraAtual);
    });
});
