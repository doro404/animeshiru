import { apianimesrecente } from "./config.js";

document.addEventListener('DOMContentLoaded', () => {
    
    fetch(apianimesrecente)
        .then(response => response.json())
        .then(data => {
            const swiperWrapper = document.querySelector('.swiper-wrapper');
            const episodesContainer = document.querySelector('.cards__container');

            if (!swiperWrapper) {
                console.error('Elemento com a classe "swiper-wrapper" não encontrado.');
                return;
            }

            if (!episodesContainer) {
                console.error('Elemento com a classe "cards__container" não encontrado.');
                return;
            }

            const calculateTimeAgo = (date) => {
                const now = new Date();
                const postDate = new Date(date);
                const diffInMs = now - postDate;
                const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
                const diffInDays = Math.floor(diffInHours / 24);

                if (diffInDays > 0) {
                    return `há ${diffInDays} dia${diffInDays > 1 ? 's' : ''}`;
                } else {
                    return `há ${diffInHours} hora${diffInHours > 1 ? 's' : ''}`;
                }
            };

            data.forEach(anime => {
                const swiperSlide = document.createElement('div');
                swiperSlide.classList.add('swiper-slide');
            
                // Link e Imagem do anime
                const animeLink = document.createElement('a');
                animeLink.href = `./single-anime.html?id=${anime.id}`;
            
                const animeImageContainer = document.createElement('div');
                animeImageContainer.classList.add('anime-image-container');
            
                const animeCoverWrapper = document.createElement('div'); // Nova div para a imagem
                animeCoverWrapper.classList.add('anime-cover-wrapper'); // Adicione uma classe para estilizar

                const animeCover = document.createElement('img');
                animeCover.src = anime.capa;
                animeCover.classList.add('swiper-slide__cover');
                animeCoverWrapper.appendChild(animeCover); // Adiciona a imagem ao novo wrapper
                animeImageContainer.appendChild(animeCoverWrapper); // Adiciona o wrapper ao contêiner
                animeLink.appendChild(animeImageContainer);
            
                // Título do anime
                const animeTitleLink = document.createElement('a');
                animeTitleLink.href = `./single-anime.html?id=${anime.id}`;
                animeTitleLink.classList.add('swiper-slide__title');
                animeTitleLink.textContent = anime.titulo;
            
                // Append elements to slide
                swiperSlide.appendChild(animeLink);
                swiperSlide.appendChild(animeTitleLink);
                swiperWrapper.appendChild(swiperSlide);
            
                // Episódio mais recente
                const latestEpisode = anime.episodios[anime.episodios.length - 1];
                const episodeCard = document.createElement('div');
                episodeCard.classList.add('episode-card');
            
                const episodeThumbnailBox = document.createElement('div');
                episodeThumbnailBox.classList.add('episode-card__thumbnail-box');
                const episodeLink = document.createElement('a');
                episodeLink.href = `#`; // Temporarily set to # to prevent default navigation
            
                const episodeImageWrapper = document.createElement('div');
                episodeImageWrapper.classList.add('episode-image-wrapper');
                
                const episodeImageContainer = document.createElement('div');
                episodeImageContainer.classList.add('episode-image-container');
            
                const episodeCoverWrapper = document.createElement('div'); // Nova div para a imagem do episódio
                episodeCoverWrapper.classList.add('episode-cover-wrapper'); // Adicione uma classe para estilizar

                const episodeThumbnailImg = document.createElement('img');
                episodeThumbnailImg.src = latestEpisode.capa_ep;
                episodeThumbnailImg.classList.add('episode-card__thumbnail-img');
                
                episodeCoverWrapper.appendChild(episodeThumbnailImg); // Adiciona a imagem ao novo wrapper
                episodeImageContainer.appendChild(episodeCoverWrapper); // Adiciona o wrapper ao contêiner
                episodeImageWrapper.appendChild(episodeImageContainer);
                episodeLink.appendChild(episodeImageWrapper);
          
        
                const languageBox = document.createElement('span');
                languageBox.classList.add('episode-card__language-box');
                languageBox.textContent = anime.selo;
            
                episodeThumbnailBox.appendChild(episodeLink);
    
                episodeThumbnailBox.appendChild(languageBox);
            
                const episodeInfo = document.createElement('div');
                episodeInfo.classList.add('episode-card__info');
            
                const episodeTitleLink = document.createElement('a');
                episodeTitleLink.href = `#`; // Temporarily set to # to prevent default navigation
                episodeTitleLink.classList.add('episode-card__title');
                episodeTitleLink.textContent = anime.titulo;
            
                const episodeDescription = document.createElement('p');
                episodeDescription.classList.add('episode-card__description');
                episodeDescription.textContent = `${latestEpisode.nome} - ${calculateTimeAgo(anime.dataPostagem)}`;
            
                episodeInfo.appendChild(episodeTitleLink);
                episodeInfo.appendChild(episodeDescription);
            
                episodeCard.appendChild(episodeThumbnailBox);
                episodeCard.appendChild(episodeInfo);
                episodesContainer.appendChild(episodeCard);
            
                // Adiciona evento de clique para redirecionar para a página do episódio
                episodeCard.addEventListener('click', (event) => {
                    event.preventDefault(); // Prevent default link behavior
                    window.location.href = `/episode?id=${anime.id}&ep=${latestEpisode.numero}`;
                });
            });

            // Inicialize o Swiper após adicionar todos os slides
            new Swiper('.swiper', {
                loop: true,
                loopFillGroupWithBlank: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                autoplay: {
                    delay: 5000, // 5 segundos em milissegundos
                    disableOnInteraction: false, // Continue autoplay após interação do usuário
                },
                spaceBetween: 20,
                breakpoints: {
                    320: {
                        slidesPerView: 2, // número de slides visíveis ao mesmo tempo no mobile
                        slidesPerGroup: 1, // número de slides passados ao clicar na navegação no mobile
                    },
                    480: {
                        slidesPerView: 2, // número de slides visíveis ao mesmo tempo no mobile
                        slidesPerGroup: 1, // número de slides passados ao clicar na navegação no mobile
                        spaceBetween: 15,
                    },
                    768: {
                        slidesPerView: 3, // número de slides visíveis ao mesmo tempo no tablet
                        slidesPerGroup: 1, // número de slides passados ao clicar na navegação no tablet
                        spaceBetween: 20,
                    },
                    1024: {
                        slidesPerView: 6, // número de slides visíveis ao mesmo tempo no desktop
                        slidesPerGroup: 2, // número de slides passados ao clicar na navegação no desktop
                        spaceBetween: 20,
                    },
                    1440: {
                        slidesPerView: 6, // número de slides visíveis ao mesmo tempo em telas grandes
                        slidesPerGroup: 6, // número de slides passados ao clicar na navegação em telas grandes
                        spaceBetween: 20,
                    },
                },
            });
        })
        .catch(error => console.error('Erro ao buscar animes:', error));
});


document.addEventListener('DOMContentLoaded', () => {
    // Sidenav search
    const sidenavSearchButton = document.getElementById('sidenav-search-button');
    const sidenavSearchInput = document.getElementById('sidenav-search-input');
    
    sidenavSearchButton.addEventListener('click', () => {
        const searchTerm = encodeURIComponent(sidenavSearchInput.value.trim());
        if (searchTerm) {
            window.location.href = `search-result?term=${searchTerm}`;
        }
    });

    // Header search
    const headerSearchButton = document.getElementById('header-search-button');
    const headerSearchInput = document.getElementById('header-search-input');
    
    headerSearchButton.addEventListener('click', () => {
        const searchTerm = encodeURIComponent(headerSearchInput.value.trim());
        if (searchTerm) {
            window.location.href = `search-result?term=${searchTerm}`;
        }
    });
});