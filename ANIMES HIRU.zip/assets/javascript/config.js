const apianimepagina = 'https://saikanet.online:3000/animesPagina/'
const apianimesrecente = 'https://saikanet.online:3000/animesRecentes/'
const apipesquisa = 'https://saikanet.online:3000/pesquisa/termo?term=';
const apitodosanimes = 'https://saikanet.online:3000/todosAnimes/';
const apiexibir = 'https://saikanet.online:3000/animes_exibir/';

export { apianimepagina, apianimesrecente, apipesquisa, apitodosanimes, apiexibir};