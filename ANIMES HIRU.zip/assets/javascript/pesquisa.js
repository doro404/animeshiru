import { apipesquisa } from "./config.js";


document.addEventListener('DOMContentLoaded', () => {
    const searchButton = document.getElementById('search-button');
    const searchInput = document.getElementById('search-input');

    if (searchButton && searchInput) {
        // Adiciona evento de clique ao botão de pesquisa
        searchButton.addEventListener('click', () => {
            const searchTerm = encodeURIComponent(searchInput.value.trim()); // Codifica o termo de pesquisa
            if (searchTerm) {
                // Redireciona para a página de resultados com o parâmetro de busca
                window.location.href = `./search-result?term=${searchTerm}`;
            }
        });
    }

    // Verifica se o parâmetro `term` está presente na URL
    const urlParams = new URLSearchParams(window.location.search);
    const term = urlParams.get('term');

    if (term) {
        // Atualiza o texto dos breadcrumbs
        const searchTermDisplay = document.getElementById('search-term-display');
        const searchTermNoResults = document.getElementById('search-term-no-results');
        if (searchTermDisplay) {
            searchTermDisplay.textContent = `"${decodeURIComponent(term)}"`;
        }
        if (searchTermNoResults) {
            searchTermNoResults.textContent = `"${decodeURIComponent(term)}"`;
        }
       
        fetch(`${apipesquisa}${term}`)
            .then(response => response.json())
            .then(data => {
                const resultsContainer = document.getElementById('anime-list-resultado-pesquisa');
                const noResultsMessage = document.getElementById('no-results-message');
                resultsContainer.innerHTML = ''; // Limpa resultados anteriores
    
                if (Array.isArray(data) && data.length > 0) {
                    // Esconde a mensagem de "Nenhum resultado encontrado"
                    noResultsMessage.style.display = 'none'
                    

                    data.forEach(anime => {
                        const animeElement = document.createElement('div');
                        animeElement.classList.add('anime-item');
    
                        animeElement.innerHTML = `
                            <div class="anime-item__left">
                                <img src="${anime.capa}" alt="${anime.titulo}" class="anime-item__cover">
                            </div>
                            <div class="anime-item__right">
                                <h2 class="anime-item__title">${anime.titulo}</h2>
                                <p class="anime-item__seal">${anime.selo}</p>
                                <div class="anime-item__genres">
                                    ${anime.genero.split(',').map(g => `<span class="anime-item__genre">${g.trim()}</span>`).join('')}
                                </div>
                            </div>
                        `;
    
                        // Adiciona evento de clique ao item de anime para redirecionar à página de detalhes
                        animeElement.addEventListener('click', () => {
                            window.location.href = `./single-anime?id=${anime.id}`;
                        });
    
                        resultsContainer.appendChild(animeElement);
                    });
                } else {
                    noResultsMessage.style.display = 'flex'
                }
            })
            .catch(error => {
                console.error('Erro ao buscar dados:', error);
            });
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const toggleSwitch = document.getElementById('theme-toggle');
    const currentTheme = localStorage.getItem('theme') || 'light-mode';

    // Aplicar o tema salvo no localStorage
    document.body.classList.add(currentTheme);

    // Atualizar o estado do toggle com base no tema atual
    if (currentTheme === 'dark-mode') {
        toggleSwitch.checked = true;
    }

    // Adicionar um ouvinte de eventos para alternar o tema
    toggleSwitch.addEventListener('change', () => {
        if (toggleSwitch.checked) {
            document.body.classList.remove('light-mode');
            document.body.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
            document.body.classList.add('light-mode');
            localStorage.setItem('theme', 'light-mode');
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    // Função para redirecionar para a página de resultados
    const performSearch = (searchInput) => {
        const searchTerm = encodeURIComponent(searchInput.value.trim());
        if (searchTerm) {
            window.location.href = `search-result?term=${searchTerm}`;
        }
    };

    // Sidenav search
    const sidenavSearchButton = document.getElementById('sidenav-search-button');
    const sidenavSearchInput = document.getElementById('sidenav-search-input');

    if (sidenavSearchButton && sidenavSearchInput) {
        sidenavSearchButton.addEventListener('click', () => performSearch(sidenavSearchInput));
        sidenavSearchInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault(); // Previne o comportamento padrão do formulário
                performSearch(sidenavSearchInput);
            }
        });
    }

    // Header search
    const headerSearchButton = document.getElementById('header-search-button');
    const headerSearchInput = document.getElementById('header-search-input');

    if (headerSearchButton && headerSearchInput) {
        headerSearchButton.addEventListener('click', () => performSearch(headerSearchInput));
        headerSearchInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault(); // Previne o comportamento padrão do formulário
                performSearch(headerSearchInput);
            }
        });
    }
});