

document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const animeId = urlParams.get('id');
    const episodeNumber = urlParams.get('ep');

    const showCommentsButton = document.getElementById('show-comments');
    if (showCommentsButton) {
        showCommentsButton.addEventListener('click', function() {
            loadDisqus();
        });
    }

    function loadDisqus() {
        const disqusThread = document.getElementById('disqus_thread');
        if (disqusThread) {
            disqusThread.style.display = 'block';

            var d = document,
                s = d.createElement('script');
            s.src = 'https://https-incriveiscuriosidades-online.disqus.com/embed.js';
            s.setAttribute('data-timestamp', +new Date());
            (d.head || d.body).appendChild(s);

            // Oculta o botão após carregar os comentários
            if (showCommentsButton) {
                showCommentsButton.style.display = 'none';
            }
        }
    }

    if (animeId && episodeNumber) {
        // Atualizar informações do episódio
        fetch(`https://saikanet.online:3000/animes_exibir/${animeId}`)
            .then(response => response.json())
            .then(data => {
                const episode = data.episodios.find(ep => ep.episodio === parseInt(episodeNumber));
                if (episode) {
                    // Atualiza o título do episódio
                    document.getElementById('episode-title').textContent = episode.descricao;

                    const playerContainer = document.getElementById('episode-player');
                    playerContainer.innerHTML = '';

                    // Verifica o tipo de link e adiciona o conteúdo adequado
                    if (episode.link.endsWith('.mp4')) {
                        // Configura o JW Player
                        jwplayer('episode-player').setup({
                            file: episode.link,
                            width: '100%',
                            aspectratio: '16:9',
                            autostart: false,
                            mute: false,
                            primary: 'html5',
                            skin: {
                                name: 'bekle'
                            }
                        });
                    } else if (episode.link.includes('blogger.com/video.g')) {
                        const iframe = document.createElement('iframe');
                        iframe.src = episode.link;
                        iframe.style.width = '100%';
                        iframe.style.height = '500px'; // Ajuste a altura conforme necessário
                        iframe.frameBorder = '0'; // Remove bordas do iframe
                        playerContainer.appendChild(iframe);
                    } else {
                        console.error('Link de vídeo inválido');
                    }

                    // Atualiza os botões de navegação
                    const prevEpisode = data.episodios.find(ep => ep.episodio === parseInt(episodeNumber) - 1);
                    const nextEpisode = data.episodios.find(ep => ep.episodio === parseInt(episodeNumber) + 1);

                    const prevEpisodeButton = document.getElementById('prev-episode');
                    const nextEpisodeButton = document.getElementById('next-episode');

                    prevEpisodeButton.style.display = prevEpisode ? 'flex' : 'none';
                    nextEpisodeButton.style.display = nextEpisode ? 'flex' : 'none';

                    prevEpisodeButton.href = prevEpisode ? `episode?id=${animeId}&ep=${prevEpisode.episodio}` : '#';
                    nextEpisodeButton.href = nextEpisode ? `episode?id=${animeId}&ep=${nextEpisode.episodio}` : '#';
                } else {
                    console.error('Episódio não encontrado');
                }
            })
            .catch(error => console.error('Error fetching episode data:', error));

        // Atualizar informações do anime
        fetch(`https://saikanet.online:3000/todosAnimes/${animeId}`)
            .then(response => response.json())
            .then(data => {

                // Atualiza a capa, título e sinopse do anime
                const animeInfo = document.querySelector('.anime-info');

                // Atualiza a capa do anime
                const animeCoverLink = animeInfo.querySelector('.anime-info__cover a');
                const animeTituloLink = animeInfo.querySelector('.anime-info__summary a');
                const animeCoverImg = animeInfo.querySelector('.anime-info__img');
                animeCoverImg.src = data.capa;
                animeTituloLink.href = `./single-anime?id=${animeId}`; // Ajuste o link se necessário
                animeCoverLink.href = `./single-anime?id=${animeId}`; // Ajuste o link se necessário

                // Atualiza o título e sinopse do anime
                const animeTitle = animeInfo.querySelector('.anime-info__title');
                const animeSynopsis = animeInfo.querySelector('.anime-info__synopsis');
                animeTitle.textContent = data.titulo;
                animeSynopsis.textContent = data.sinopse;

                // Atualiza o breadcrumb
                const breadcrumbs = document.querySelector('.breadcrumbs__text');
                breadcrumbs.innerHTML = `
                    <a href="/" class="breadcrumbs__link">Home</a>
                    <span class="breadcrumbs__arrow">»</span>
                    <a href="/" class="breadcrumbs__link">Animes</a>
                    <span class="breadcrumbs__arrow">»</span>
                    <a href="./single-anime?id=${animeId}" class="breadcrumbs__link">${data.titulo}</a>
                    <span class="breadcrumbs__arrow">»</span>
                    Episódio ${episodeNumber}
                `;
            })
            .catch(error => console.error('Error fetching anime data:', error));
    } else {
        console.error('Anime ID ou número do episódio não encontrado na URL');
    }
});
